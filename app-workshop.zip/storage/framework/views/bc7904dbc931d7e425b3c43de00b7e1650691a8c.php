<?php $__env->startSection('title'); ?>
<?php echo e($curso->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid hero" style="background-image: url('<?php echo e(asset('uploads/'.$curso->portrait)); ?>')">
   <div class="container">
      <div class="row pt-5 pb-5">
         <section class="col-12 col-md-8 p-2 text-white shadow-text">
            <h1 class="header-line"><small><?php echo e($curso->type); ?></small><br><?php echo e($curso->title); ?></h1>
            <h2> <small class="text-info">Dirigido por:</small><br><?php echo e($curso->name); ?></h2><br>
            <div class="d-flex flex-wrap align-items-center">
               <h4><i class="fa fa-calendar text-info" aria-hidden="true"></i> <?php echo e($curso->fecha); ?> </h4> &nbsp;&nbsp;&nbsp;
               <h4> <i class="fa fa-clock-o text-info" aria-hidden="true"></i> de <?php echo e($curso->schedule); ?></h4>  
               
            </div>
         </section>
         <section class="col-12 col-md-4 p-2">
            <div class="card">						
               <div class="card-header bg-secondary bg-gradient text-white">
                  <div class="card-title text-center">
                     <h3>¡Regístrate Ya!</h3>
                     <p>Completa tus datos y nosotros te llamamos</p>
                     <?php if(session('msg')): ?>
                     <div class="alert alert-success">
                        <?php echo e(session('msg')); ?>

                     </div>									
                     <?php endif; ?>
                  </div>
               </div>
               <div class="card-body">               
                  <form action="<?php echo e(route('datasender')); ?>" method="POST">
                     <?php echo e(csrf_field()); ?>

                     <input type="hidden" name="curso" value="<?php echo e($curso->title); ?>">
                     <input type="hidden" name="curso_id" value="<?php echo e($curso->id); ?>">
                     <div class="mb-2">       
                        <input type="text" class="form-control" id="name" name="name" placeholder="Nombres y apellidos">
                     </div>
                     <div class="mb-2">
                        <input type="number" class="form-control" id="phone" name="phone" placeholder="Nro telefonico">
                     </div>
                     <div class="mb-2">
                        <input type="email" class="form-control" id="email" name="email" placeholder="Correo electrónico">
                     </div>
                     <div class="mb-2">
                        <textarea name="message" id="message" class="form-control" rows="3" placeholder="Deseo participar"></textarea>
                     </div>
                     <div class="d-grid gap-2">                        
                        <input type="submit" class="btn btn-dark" value="Registrar">             
                     </div>
                  </form>
               </div>         
            </div>
         </section>
      </div>
   </div>
</div>

<div class="separator-block"> &nbsp; </div>

<div class="container-fluid mt-5" id="docente">
   <div class="container">
      <div class="row"><section class="col-12"><div class="titlezone bg-dark text-white"> <p><i class="fa fa-caret-right" aria-hidden="true"></i> Sobre el docente:</p> </div></section></div>
      <div class="row mt-3">
         <section class="col-12 col-md-4 text-center p-4">

            <div class="card">
               <img src="<?php echo e(asset('uploads/'.$curso->url_profile)); ?>" class="card-img-top circle-profile" alt="<?php echo e($curso->name); ?>">
               <div class="card-body text-center">
                 <h5 class="card-title"> <strong><?php echo e($curso->name); ?></strong><br><small class="text-minimalist text-secondary"> <?php echo e($curso->jobtitle); ?> </small></h5>

                 <div class="d-flex flex-wrapd-flex justify-content-around mt-3">
                  <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <a href="<?php echo e($social->url_social); ?>" class="btn btn-outline-dark"> <i class="<?php echo e($social->icon); ?>" aria-hidden="true"></i> </a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  
                 </div>
               </div>
             </div>
            
         </section>
         <section class="col-12 col-md-8 p-4">
            <h4 class="text-info">Reseña profesional:</h4>
            <p><?php echo $curso->bio; ?></p>
         </section>
      </div>
   </div>
</div>

<div class="separator-block"> &nbsp; </div>

<div class="container-fluid mt-5">
   <div class="container">
      <div class="row"><section class="col-12"><div class="titlezone bg-dark text-white"> <p><i class="fa fa-caret-right" aria-hidden="true"></i> Descripción:</p> </div></section></div>
      <div class="row mt-3">
         <section class="col-12 col-md-6">
            <h4 class="text-secondary"><i class="fa fa-check-square" aria-hidden="true"></i> Objetivos:</h4>
            <p><?php echo $curso->objectives; ?></p>
            <br>
            <h4 class="text-secondary"><i class="fa fa-users" aria-hidden="true"></i> Dirigido a:</h4>
            <p><?php echo $curso->public; ?></p>
         </section>
         <section class="col-12 col-md-6 d-flex align-items-center">
            <img src="<?php echo e(asset('uploads/'.$curso->description)); ?>" class="img-fluid" alt="">
         </section>
      </div>
   </div>
</div>

<div class="separator-block"> &nbsp; </div>

<div class="container-fluid mt-5" id="temas">
   <div class="container">
      <div class="row"><section class="col-12"><div class="titlezone bg-dark text-white"> <p><i class="fa fa-caret-right" aria-hidden="true"></i> Metodología:</p> </div></section></div>
      <div class="row mt-3">
         <section class="col-12 col-md-8">

            <div class="accordion" id="accordionExample">
               <?php $__currentLoopData = $syllabus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sylabo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <div class="accordion-item">
                  <h2 class="accordion-header" id="encabezado<?php echo e($sylabo->id); ?>">
                    <button class="accordion-button bg-info bg-gradient text-dark" type="button" data-bs-toggle="collapse" data-bs-target="#tema<?php echo e($sylabo->id); ?>" aria-expanded="true" aria-controls="tema<?php echo e($sylabo->id); ?>">
                      <?php echo e($sylabo->module); ?>

                    </button>
                  </h2>
                  <?php if($loop->iteration==1): ?>
                  <div id="tema<?php echo e($sylabo->id); ?>" class="accordion-collapse collapse show" aria-labelledby="encabezado<?php echo e($sylabo->id); ?>" data-bs-parent="#accordionExample">
                     <div class="accordion-body">
                       <?php echo $sylabo->info; ?>

                     </div>
                  </div>
                  <?php else: ?>
                  <div id="tema<?php echo e($sylabo->id); ?>" class="accordion-collapse collapse" aria-labelledby="encabezado<?php echo e($sylabo->id); ?>" data-bs-parent="#accordionExample">
                     <div class="accordion-body">
                       <?php echo $sylabo->info; ?>

                     </div>
                  </div>
                  <?php endif; ?>
                  
               </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
             </div>
         </section>
         <section class="col-12 col-md-4">
            <h4 class="mt-2">Detalles del Curso</h4>
            <ul class="list-group list-group-flush">
               <li class="list-group-item d-flex align-items-around">
                  <div><h2><i class="fa fa-calendar text-info" aria-hidden="true"></i></h2></div>
                  <div class="px-2"><h5> <small>Días</small><br> <strong><?php echo e($curso->fecha); ?></strong></h5></div>
               </li>
               <li class="list-group-item d-flex align-items-around">
                  <div><h2><i class="fa fa-list-alt text-info" aria-hidden="true"></i></h2></div>
                  <div class="px-2"><h5> <small>Horario</small><br> <strong>de <?php echo e($curso->schedule); ?></strong></h5></div>
               </li>
               <li class="list-group-item d-flex align-items-around">
                  <div><h2><i class="fa fa-clock-o text-info" aria-hidden="true"></i></h2></div>
                  <div class="px-2"><h5> <small>Duración</small><br> <strong><?php echo e($curso->duration); ?> / <?php echo e($curso->session); ?> Sesiones</strong></h5></div>
               </li>
             </ul>
         </section>
      </div>
   </div>
</div>

<div class="separator-block"> &nbsp; </div>

<div class="container-fluid hero mt-5 pt-2 pb-2" style="background-image: url('<?php echo e(asset('uploads/'.$curso->inversion)); ?>')" id="inversion">
   <div class="container bg-fader">
      <div class="row"><section class="col-12"><div class="titlezone bg-dark text-white"> <p><i class="fa fa-caret-right" aria-hidden="true"></i> Inversión:</p> </div></section></div>
      <div class="row mt-3">

         <?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <section class="col-12 col-md-6">
            <div class="card text-center">
               <div class="card-header bg-secondary text-info">
                  <h3><?php echo e($price->info); ?></h3>
               </div>
               <div class="card-body">
                  <?php if($price->promo==1): ?>
                     <h1>S/. <?php echo e($price->amount); ?></h1>
                     <h2 class="text-secondary text-decoration-line-through">S/. <?php echo e($price->dscto); ?></h2>
                     <h6><small class="bg-danger text-white">Ahorre S/. <?php echo e($price->amount - $price->dscto); ?></small></h6>
                  <?php else: ?>
                     <h1>S/. <?php echo e($price->amount); ?></h1>
                  <?php endif; ?>
             </div>
         </section>
         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <section class="col-12 text-center mt-3 mb-3">
            <p>Precios incluyen IGV</p>
         </section>
      </div>
   </div>

   <div class="container bg-fader mt-4">
      <div class="row"><section class="col-12"><div class="titlezone bg-dark text-white"> <p><i class="fa fa-caret-right" aria-hidden="true"></i> Formas de pago:</p> </div></section></div>
      <div class="row mt-3">
         <section class="col-12 col-md-6">
            <div class="card">
               <div class="card-header bg-secondary text-white text-center">
                 <h4 class="shadow-text">Plataforma CONSTRUCTIVO</h4>
               </div>
               <div class="card-body">
                  <div class="row">
                     <section class="col-12 col-md-9">
                        <p class="card-text">Compre el curso directamente y reserve su participación. Reserve su cupo desde aqui.</p>                        
                     </section>
                     <section class="col-md-3 d-none d-sm-block">
                        <img src="<?php echo e(asset('images/pc.png')); ?>" class="img-fluid" alt="">
                     </section>
                  </div>
                  <div class="row mt-3">
                     <section class="col-12 col-md-2">
                        <a href="https://plataforma.constructivo.com/curso/como-crear-un-espacio-verde-y-sostenible-5ff62a15daf11" target="_blank" class="btn btn-dark">Adquirir</a>
                     </section>
                     <section class="col-md-10 d-none d-sm-block">
                        <img src="<?php echo e(asset('images/cards.png')); ?>" class="img-fluid" alt="">
                     </section>
                  </div>        
               </div>
             </div>
         </section>
         <section class="col-12 col-md-6">
            <div class="card">
               <div class="card-header bg-secondary text-white text-center">
                 <h4 class="shadow-text">Depósito / Transferencia</h4>
               </div>
               <div class="card-body">
                  <div class="row">
                     <section class="col-12 col-md-10">
                        <p>PULL CREATIVO COMUNICACIONES S.A.C. RUC: 20601694876</p>
                        <ul>
                           <li><strong>CTA. CTE. SOLES 193-2366918-0-60 (BCP)</strong></li>
                           <li><strong>CTA. CCI. SOLES 002-193-002366918060-18 (BCP)</strong></li>
                        </ul>
                     </section>
                     <section class="col-md-2 d-none d-sm-block">
                        <img src="<?php echo e(asset('images/bcp.jpg')); ?>" class="img-fluid" alt="">
                     </section>
                  </div>
               </div>
             </div>
         </section>
      </div>
   </div>
</div>

<div class="separator-block"> &nbsp; </div>

<div class="container-fluid mt-5">
   <div class="container">
      <div class="row"><section class="col-12"><div class="titlezone bg-dark text-white"> <p><i class="fa fa-caret-right" aria-hidden="true"></i> Beneficios:</p> </div></section></div>
      <div class="row mt-3">
         <section class="col-12 col-md-6">
            <h4 class="text-info"><i class="fa fa-certificate" aria-hidden="true"></i> Incluye:</h4>
            <ul class="mt-3">
               <?php $__currentLoopData = $benefits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $benefit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
               <li><?php echo e($benefit->benefit); ?></li>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>               
               
            </ul>
         </section>
         <section class="col-12 col-md-6">
            <img src="<?php echo e(asset('images/class.jpg')); ?>" class="img-fluid" alt="">
         </section>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.front', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/dossierd/app-workshop/resources/views/index.blade.php ENDPATH**/ ?>