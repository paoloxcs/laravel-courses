<table>
	<thead>
		<tr>
			<th>Nombre</th>
			<th>Teléfono</th>
			<th>Correo Electrónico</th>
			<th>Consulta</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td><?php echo e($data['name']); ?></td>
			<td><?php echo e($data['phone']); ?></td>
			<td><?php echo e($data['email']); ?></td>
			<td><?php echo e($data['message']); ?></td>
		</tr>
	</tbody>
</table><?php /**PATH C:\laragon\www\app-workshop\resources\views/emails/datasender.blade.php ENDPATH**/ ?>