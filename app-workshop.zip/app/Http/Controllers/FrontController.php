<?php

namespace App\Http\Controllers;
use DB;
use App\Course;
use App\Picture;
use App\Price;
use App\Benefit;
use App\Social;
use App\Instructor;
use App\Entry;
use App\Mail\dataSender;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;

class FrontController extends Controller
{
    public function index($slug)
    {
        $curso=DB::table('courses as c')
        ->join('instructors as i','c.instructor_id','=','i.id')
        ->select('c.id','c.type', 'c.title' , 'c.fecha', 'c.schedule', 'i.name', 'i.jobtitle', 'i.bio','c.objectives', 'c.public', 'c.duration', 'c.portrait', 'c.description', 'c.inversion' ,'c.session' ,'i.id as docente_id', 'i.url_profile')
        ->where([['c.slug','=',$slug],['c.is_active','=',1]])
        ->first();
        $id=$curso->id;
        $docente=$curso->docente_id;

        $socials=DB::table('instructor_social as s')
        ->join('instructors as i','s.instructor_id','=','i.id')
        ->where('i.id','=',$docente)->get();

        $syllabus=DB::table('course_syllabus as s')
        ->join('courses as c','s.course_id','=','c.id')
        ->where('s.course_id','=',$id)->get();

        $prices=DB::table('course_prices as p')
        ->join('courses as c','p.course_id','=','c.id')
        ->where('p.course_id','=',$id)->get();

        $benefits=DB::table('course_benefits as b')
        ->join('courses as c','b.course_id','=','c.id')
        ->where('b.course_id','=',$id)->get();

        
        // $curso = Course::where('slug',$slug)->first();
        if ($curso != null) {
            return view('index',compact('curso','socials', 'syllabus', 'prices', 'benefits', 'picture'));
        }else{
            return view('errors.404');
        }            
    }

    public function dataSender(Request $request)
    {
    	// dd($request->all());
    	$this->validate($request,[
    		'name'=>'required|string|max:80',
    		'phone'=>'required|numeric',
    		'email'=>'required|email',
    		'message'=>'required|string'		
    	],[
    		'name.required'=>'Este campo es requerido',
    		'phone.required'=>'El teléfono es requerido',
    		'email.required'=>'El correo electrónico es requerido',
    		'message.required'=>'Escriba aqui su mensaje'
    	]);

    	$data=[
    		'name'=>$request->name,
    		'phone'=>$request->phone,
    		'email'=>$request->email,
            'message'=>$request->message,
            'curso'=>$request->curso,
    		'curso_id'=>$request->curso_id
        ];

        $entry=new Entry();
        $entry->fullname=$request->name;
        $entry->phone=$request->phone;
        $entry->email=$request->email;
        $entry->message=$request->message;
        $entry->course_id=$request->curso_id;
        $entry->save();
    	Mail::to('info2@constructivo.com')->cc('info@constructivo.com')
        //Mail::to('postmaster2@constructivo.com')
    	->send(new dataSender($data));
    	// Session::flash('msg', 'Su información fue enviada con éxito.'); //para otra vista/ruta
        return back()->with('msg', 'Su información fue enviada con éxito.');
    }

}
